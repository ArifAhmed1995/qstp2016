function X=warmUp_1(a,b)
% A= warmUp_1 is an exercise wherein we need to find & return the greatest of two numbers 
% ========= BEGIN YOUR CODE HERE ===========
	if (a > b)
		X = a;
	else
		X = b; 
	endif 	
return;
endfunction
% ============== END ========================
