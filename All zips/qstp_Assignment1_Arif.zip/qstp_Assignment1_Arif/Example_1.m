function A=warmUp_1(r)
% A= warmUp_1 is an exercise wherein we need to calculate area of a circle with radii as an input  
% ============= YOUR CODE HERE ==============
% Instructions: Return the 5x5 identity matrix 
%               In octave, we return values by defining which variables
%               represent the return values (at the top of the file)
%               and then set them accordingly. 
%============== BEGIN =======================
A=pi*(r^2)
% ============== END ========================
end
